package models

/*import (
    "golanger.com/utils"
)

var (
    ColTableName = utils.M{
        "name":  "table_name",
        "index": []string{
            "id,table",
            "key,time",
        },
        "unique": []string{
            "id",
            "table,key",
        },
    }
)

/ *测试表
table_name {
    "id" : <Int64>,
    "table" : <String>,
    "key" : <String>,
    "expires" : <Int>,
    "time" : <Int64>
}
* /

type ModelTableName struct {
    Id      int64
    Table   string
    Key     string
    Expires int
    Time    int64
}
*/
