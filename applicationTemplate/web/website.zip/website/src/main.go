package main

import (
	. "controllers"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	_ "templateFunc"
)

var (
	addr       = flag.String("addr", ":80", "Server port")
	configPath = flag.String("config", "./config/site", "site filepath of config")
)

func main() {
	runtime.GOMAXPROCS(runtime.NumCPU()*2 + 1)

	flag.Parse()
	os.Chdir(filepath.Dir(os.Args[0]))
	fmt.Println("Listen server address: " + *addr)
	fmt.Println("Read configuration file success, fithpath: " + filepath.Join(filepath.Dir(os.Args[0]), *configPath))

	App.Load(*configPath)

	//App.AddHeader("Content-Type", "text/html; charset=utf-8")
	App.HandleFavicon() //如果静态文件交由nginx等处理，可以去掉次方法
	App.HandleStatic()  //如果静态文件交由nginx等处理，可以去掉次方法
	App.ListenAndServe(*addr, App)
}
